// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
exports.handler = async (event, context) => {
    console.log('Received event:', prettyPrint(event))
    console.log('Received context:', prettyPrint(context))
};

function prettyPrint(obj) {
    return JSON.stringify(obj, null, 2);
}
